/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pruebas;


import view.login1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author afprietoa
 */
public class play {
    public static void main(String[] args) {
        
        login1 bodega = new login1();
        bodega.setBounds(500, 200, 500, 500);
        bodega.setVisible(true);
    }
}
